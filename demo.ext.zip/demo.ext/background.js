console.log("Checking user's settings on firebase")
const userName = 'newUSER@gamil.com';
const password = 'huhf3';

const firebaseConfig = {
    apiKey: "AIzaSyCgWNooW56Q8PPXRPrK0aOEKaq43Q6DIJ0",
    authDomain: "study-focus-project.firebaseapp.com",
    projectId: "study-focus-project",
    storageBucket: "study-focus-project.appspot.com",
    messagingSenderId: "433223165280",
    appId: "1:433223165280:web:5ff34eadd6dff07ed12a05",
    measurementId: "G-DBYMEXR3F1"
};

// Initialize Firebase
//const app = initializeApp(firebaseConfig);
//const analytics = getAnalytics(app);

firebase.initializeApp(firebaseConfig);
console.log(firebase);

const auth = firebase.auth();
const promise = auth.signInWithEmailAndPassword(userName, password);
promise.catch(authResponse => console.log(authResponse.message));
console.log("Logged in successfully!")

var db = firebase.firestore();

var email = 'user1@email.com'

var userInfoRef = db.collection("users").doc(email);

userInfoRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data", doc.data());
    } else {
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});